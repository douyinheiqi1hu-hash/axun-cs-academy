const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const net = require('node:net');
const { spawn } = require('node:child_process');
const { setTimeout: delay } = require('node:timers/promises');

const root = path.resolve(__dirname, '..');
const address = 'http://127.0.0.1:5174/';
const logs = path.join(root, 'qa');

function probe() {
  return new Promise(resolve => {
    let finished = false;
    const finish = value => { if (!finished) { finished = true; resolve(value); } };
    const request = http.get(address, response => {
      let content = '';
      response.setEncoding('utf8');
      response.on('data', chunk => {
        content += chunk;
        if (content.length > 100000) { finish(false); response.destroy(); }
      });
      response.on('end', () => finish(response.statusCode === 200 && content.includes('<title>阿勋CS基础学院')));
      response.on('error', () => finish(false));
    });
    request.setTimeout(1200, () => { request.destroy(); finish(false); });
    request.on('error', () => finish(false));
  });
}

function portInUse() {
  return new Promise(resolve => {
    const socket = net.createConnection({ host: '127.0.0.1', port: 5174 });
    const finish = value => { socket.destroy(); resolve(value); };
    socket.setTimeout(700);
    socket.once('connect', () => finish(true));
    socket.once('error', () => finish(false));
    socket.once('timeout', () => finish(false));
  });
}

function openWebsite() {
  if (process.argv.includes('--no-open')) return;
  const opener = spawn('rundll32.exe', ['url.dll,FileProtocolHandler', address], {
    detached: true, windowsHide: true, stdio: 'ignore',
  });
  opener.once('error', () => console.log(`请在浏览器打开 ${address}`));
  opener.unref();
}

(async () => {
  if (await probe()) {
    console.log(`学院网站已在运行：${address}`);
    openWebsite();
    return;
  }
  if (await portInUse()) {
    // Give an already-starting Vite process time to answer before diagnosing a conflict.
    await delay(800);
    if (await probe()) { console.log(`学院网站已在运行：${address}`); openWebsite(); return; }
    throw new Error('5174 端口正被其他程序占用，请检查后重试；没有关闭或修改其他程序');
  }

  const vite = path.join(root, 'node_modules', 'vite', 'bin', 'vite.js');
  if (!fs.existsSync(vite)) throw new Error('网站依赖缺失，请在项目目录安装依赖后重试');
  fs.mkdirSync(logs, { recursive: true });
  const output = fs.openSync(path.join(logs, 'preview-server.log'), 'w');
  const errors = fs.openSync(path.join(logs, 'preview-server-error.log'), 'w');
  let service;
  try {
    service = spawn(process.execPath, [vite, '--host', '127.0.0.1', '--port', '5174', '--strictPort'], {
      cwd: root, detached: true, windowsHide: true, stdio: ['ignore', output, errors],
    });
    await new Promise((resolve, reject) => {
      service.once('spawn', resolve);
      service.once('error', reject);
    });
    service.unref();
  } finally {
    fs.closeSync(output); fs.closeSync(errors);
  }

  for (let attempt = 0; attempt < 24; attempt++) {
    if (await probe()) {
      console.log(`学院网站已启动：${address}`);
      console.log('网站在后台运行，可以关闭这个窗口；电脑重启后需再次双击启动');
      openWebsite();
      return;
    }
    await delay(350);
  }
  throw new Error(`启动未成功，请查看 ${path.join(logs, 'preview-server-error.log')}`);
})().catch(error => { console.error(`\n${error.message}`); process.exitCode = 1; });
