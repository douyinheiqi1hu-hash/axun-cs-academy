import React, { useLayoutEffect, useRef } from 'react';
import { gsap } from 'gsap';
import './HeroAtmosphere.css';

const dust = [
  [47, 62, 2], [55, 41, 3], [64, 72, 2], [73, 49, 2],
  [82, 65, 3], [91, 37, 2], [59, 84, 2], [77, 28, 2],
  [88, 81, 2], [44, 33, 2], [68, 57, 3], [95, 57, 2],
];

/** The opening, ambient camera, mouse depth and scroll image each own a layer. */
export default function HeroAtmosphere({ enabled }) {
  const imageRef = useRef(null);

  useLayoutEffect(() => {
    const hero = imageRef.current?.closest('.scene-hero');
    if (!hero || !enabled) return undefined;

    const finePointer = matchMedia('(hover: hover) and (pointer: fine)');
    const smallScreen = matchMedia('(max-width: 700px)');
    const forcedColors = matchMedia('(forced-colors: active)');
    const depth = hero.querySelector('.hero-depth-layer');
    const modal = document.querySelector('.scene-modal');
    let rect = hero.getBoundingClientRect();
    let measuredScroll = window.scrollY;
    let visible = rect.bottom > 0 && rect.top < innerHeight;
    let active = false;
    let disposed = false;
    let loop;
    let desktopLoop;
    let xTo;
    let yTo;

    const context = gsap.context(() => {
      loop = gsap.timeline({ paused: true });
      desktopLoop = gsap.timeline({ paused: true });
      loop.fromTo('.hero-camera-drift',
        { x: -10, y: 5, scale: 1.015 },
        { x: 12, y: -9, scale: 1.05, duration: 15, repeat: -1, yoyo: true, ease: 'sine.inOut' }, 0);

      loop.fromTo('.atmosphere-daylight',
        { xPercent: -10, yPercent: -4, rotation: -8, opacity: 0.28 },
        { xPercent: 13, yPercent: 7, rotation: 5, opacity: 0.7, duration: 9, repeat: -1, yoyo: true, ease: 'sine.inOut' }, 0);
      loop.fromTo('.atmosphere-cyan',
        { xPercent: 9, yPercent: 7, scale: 0.9, opacity: 0.32 },
        { xPercent: -12, yPercent: -10, scale: 1.12, opacity: 0.7, duration: 11, repeat: -1, yoyo: true, ease: 'sine.inOut' }, 0);
      loop.fromTo('.atmosphere-ground',
        { xPercent: -12, opacity: 0.18 },
        { xPercent: 12, opacity: 0.42, duration: 12, repeat: -1, yoyo: true, ease: 'sine.inOut' }, 0);

      hero.querySelectorAll('.atmosphere-dust').forEach((mote, index) => {
        // Extra particles and SVG trails have their own paused timeline on mobile.
        const duration = 6.5 + (index % 4) * 1.1;
        const drift = gsap.timeline({ repeat: -1, repeatDelay: (index % 3) * 0.55 });
        drift.fromTo(mote, { x: 0, y: 18, opacity: 0 },
          { x: index % 2 ? -38 : 30, y: -80 - (index % 3) * 15, duration, ease: 'none' }, 0)
          .to(mote, { opacity: index % 3 ? 0.6 : 0.9, duration: 1.6, ease: 'sine.inOut' }, 0)
          .to(mote, { opacity: 0, duration: 1.8, ease: 'sine.inOut' }, duration - 1.8);
        (index < 6 ? loop : desktopLoop).add(drift, index * 0.38);
      });

      hero.querySelectorAll('.trajectory-flow').forEach((track, index) => {
        const paths = track.querySelectorAll('path');
        const length = paths[0].getTotalLength();
        gsap.set(paths, { strokeDasharray: `${length * 0.12} ${length}`, strokeDashoffset: length });
        desktopLoop.to(paths, {
          strokeDashoffset: -length * 0.12, duration: 4.8 + index * 1.2,
          repeat: -1, repeatDelay: 0.5, ease: 'none',
        }, 1.5 + index * 1.7);
      });

      hero.querySelectorAll('.pin-ripple').forEach((ring, index) => {
        loop.fromTo(ring, { scale: 0.85, opacity: 0.6 },
          { scale: 1.95, opacity: 0, duration: 3, repeat: -1, repeatDelay: 0.8, ease: 'power1.out' }, index * 0.7);
      });

      // These reusable tweens are created inside the context and never move hit areas.
      xTo = gsap.quickTo(depth, 'x', { duration: 0.65, ease: 'power2.out' });
      yTo = gsap.quickTo(depth, 'y', { duration: 0.65, ease: 'power2.out' });
    }, hero);

    const resetPointer = (immediate = false) => {
      xTo(0); yTo(0);
      if (immediate) {
        xTo.tween.progress(1).pause();
        yTo.tween.progress(1).pause();
      }
    };
    const syncPlayback = () => {
      if (disposed) return;
      const next = visible && !document.hidden && !forcedColors.matches && !modal?.open;
      active = next;
      hero.dataset.atmosphere = active ? 'running' : 'paused';
      if (active) {
        loop.resume();
        if (smallScreen.matches) desktopLoop.pause();
        else desktopLoop.resume();
      } else { loop.pause(); desktopLoop.pause(); resetPointer(true); }
    };
    const measure = () => {
      rect = hero.getBoundingClientRect();
      measuredScroll = window.scrollY;
      if (!finePointer.matches || smallScreen.matches) resetPointer(true);
      syncPlayback();
    };
    const onPointerMove = event => {
      if (!active || !finePointer.matches || smallScreen.matches || event.pointerType !== 'mouse') return;
      if (event.buttons !== 0) { resetPointer(); return; }
      const top = rect.top - (window.scrollY - measuredScroll);
      const x = gsap.utils.clamp(-1, 1, ((event.clientX - rect.left) / rect.width - 0.5) * 2);
      const y = gsap.utils.clamp(-1, 1, ((event.clientY - top) / rect.height - 0.5) * 2);
      xTo(-x * 16); yTo(-y * 11);
    };
    const onPointerLeave = () => resetPointer(!active);
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting && entry.intersectionRatio > 0.05;
      syncPlayback();
    }, { threshold: [0, 0.05] });
    observer.observe(hero);
    const modalObserver = modal ? new MutationObserver(syncPlayback) : null;
    modalObserver?.observe(modal, { attributes: true, attributeFilter: ['open'] });

    hero.dataset.atmosphere = 'paused';
    syncPlayback();
    hero.addEventListener('pointerenter', measure, { passive: true });
    hero.addEventListener('pointermove', onPointerMove, { passive: true });
    hero.addEventListener('pointerleave', onPointerLeave, { passive: true });
    hero.addEventListener('pointerdown', onPointerLeave, { passive: true });
    hero.addEventListener('pointercancel', onPointerLeave, { passive: true });
    hero.addEventListener('dragstart', onPointerLeave, { passive: true });
    window.addEventListener('blur', onPointerLeave);
    window.addEventListener('resize', measure, { passive: true });
    document.addEventListener('visibilitychange', syncPlayback);
    finePointer.addEventListener('change', measure);
    smallScreen.addEventListener('change', measure);
    forcedColors.addEventListener('change', syncPlayback);

    return () => {
      disposed = true;
      observer.disconnect();
      modalObserver?.disconnect();
      hero.removeEventListener('pointerenter', measure);
      hero.removeEventListener('pointermove', onPointerMove);
      hero.removeEventListener('pointerleave', onPointerLeave);
      hero.removeEventListener('pointerdown', onPointerLeave);
      hero.removeEventListener('pointercancel', onPointerLeave);
      hero.removeEventListener('dragstart', onPointerLeave);
      window.removeEventListener('blur', onPointerLeave);
      window.removeEventListener('resize', measure);
      document.removeEventListener('visibilitychange', syncPlayback);
      finePointer.removeEventListener('change', measure);
      smallScreen.removeEventListener('change', measure);
      forcedColors.removeEventListener('change', syncPlayback);
      xTo.tween.kill(); yTo.tween.kill();
      context.revert();
      depth.style.removeProperty('transform');
      delete hero.dataset.atmosphere;
    };
  }, [enabled]);

  return <>
    <div ref={imageRef} className="hero-image-wrap" data-hero-image>
      <div className="hero-depth-layer"><div className="hero-camera-drift"><picture>
        <source media="(max-width:700px)" srcSet="/academy/courtyard-960.webp"/>
        <img className="hero-landscape" src="/academy/courtyard-1920.webp" width="1774" height="887"
          alt="石拱门通向阳光中的虚构CS训练场景，建筑与训练箱构成纵深" fetchPriority="high" data-scene-parallax="30"/>
      </picture></div></div>
    </div>
    <div className="hero-atmosphere" aria-hidden="true">
      <div className="atmosphere-daylight"/><div className="atmosphere-cyan"/><div className="atmosphere-ground"/>
      {dust.map(([left, top, size], index) => <span key={index} className="atmosphere-dust"
        style={{ left: `${left}%`, top: `${top}%`, width: size, height: size }}/>)}
    </div>
  </>;
}
