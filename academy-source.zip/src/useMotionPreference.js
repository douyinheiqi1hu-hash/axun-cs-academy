import { useEffect, useLayoutEffect, useState } from 'react';

const STORAGE_KEY = 'axun-academy-motion';
function readPreference() {
  try { const value = localStorage.getItem(STORAGE_KEY); return ['on', 'off'].includes(value) ? value : 'auto'; }
  catch { return 'auto'; }
}

// Respect the device by default; an explicit choice only applies to this site.
export default function useMotionPreference() {
  const [preference, setPreference] = useState(readPreference);
  const [reduced, setReduced] = useState(() => matchMedia('(prefers-reduced-motion: reduce)').matches);
  const enabled = preference === 'on' || (preference === 'auto' && !reduced);
  useEffect(() => {
    const query = matchMedia('(prefers-reduced-motion: reduce)');
    const onChange = () => setReduced(query.matches);
    const onStorage = event => { if (event.key === STORAGE_KEY) setPreference(readPreference()); };
    query.addEventListener('change', onChange);
    window.addEventListener('storage', onStorage);
    return () => { query.removeEventListener('change', onChange); window.removeEventListener('storage', onStorage); };
  }, []);
  useLayoutEffect(() => {
    const old = document.documentElement.getAttribute('data-motion');
    document.documentElement.dataset.motion = enabled ? 'on' : 'off';
    return () => { if (old === null) document.documentElement.removeAttribute('data-motion'); else document.documentElement.setAttribute('data-motion', old); };
  }, [enabled]);
  const setEnabled = value => {
    const next = value ? 'on' : 'off';
    try { localStorage.setItem(STORAGE_KEY, next); } catch { /* The in-memory choice still works. */ }
    setPreference(next);
  };
  return { enabled, setEnabled, followsDevice: preference === 'auto', reduced };
}
