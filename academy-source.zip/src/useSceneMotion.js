import { useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

/** Motion is scoped to this scene; native scrolling and document focus stay intact. */
export default function useSceneMotion(rootRef, enabled = true, replayKey = 0) {
  useLayoutEffect(() => {
    const root = rootRef.current;
    if (!root || !enabled) return undefined;
    const media = gsap.matchMedia();
    let refreshFrame = 0;
    let stopped = false;
    let resizeObserver;
    let openingTimeline;

    const refresh = () => {
      if (stopped || refreshFrame) return;
      refreshFrame = window.requestAnimationFrame(() => {
        refreshFrame = 0;
        if (!stopped) ScrollTrigger.refresh();
      });
    };

    const context = gsap.context(() => {
      media.add('(min-width: 0px)', () => {
        const hero = root.querySelector('#home, .scene-hero, .hero-scene');
        const titleLines = root.querySelectorAll('.hero-word-mask > span');
        const heroImage = hero?.querySelector('[data-hero-image]');
        const navigation = root.querySelector('[data-nav-enter]');
        const heroCopy = hero?.querySelectorAll('[data-hero-copy]');
        const heroActions = hero?.querySelectorAll('[data-hero-actions]');
        const atHero = !hero || hero.getBoundingClientRect().bottom > 0;

        if (atHero) {
          // A preview opened in a background tab must not finish its opening
          // before the visitor actually switches to it.
          const opening = gsap.timeline({ paused: document.hidden, defaults: { ease: 'power3.out' } });
          openingTimeline = opening;
          if (heroImage) {
            opening.fromTo(heroImage,
              { scale: 1.08, transformOrigin: '58% 46%' },
              { scale: 1, duration: 3, clearProps: 'transform,transformOrigin' }, 0);
          }
          if (navigation) {
            opening.fromTo(navigation,
              { y: -18, autoAlpha: 0 },
              { y: 0, autoAlpha: 1, duration: 0.85, clearProps: 'transform,opacity,visibility' }, 0.12);
          }
          if (titleLines.length) {
            opening.fromTo(titleLines,
              { yPercent: 118, rotation: 1.5, transformOrigin: '0% 100%' },
              { yPercent: 0, rotation: 0, duration: 1.65, stagger: 0.2, ease: 'power2.out', clearProps: 'transform,transformOrigin' }, 0.3);
          }
          if (heroCopy?.length) {
            opening.fromTo(heroCopy,
              { y: 20, autoAlpha: 0 },
              { y: 0, autoAlpha: 1, duration: 1, stagger: 0.12, clearProps: 'transform,opacity,visibility' }, 0.82);
          }
          if (heroActions?.length) {
            opening.fromTo(heroActions,
              { y: 20, autoAlpha: 0 },
              { y: 0, autoAlpha: 1, duration: 1, stagger: 0.1, clearProps: 'transform,opacity,visibility' }, 1.03);
          }
          hero?.querySelectorAll('.trajectory > .trajectory-guide').forEach((path, index) => {
            const length = path.getTotalLength();
            opening.fromTo(path,
              { strokeDasharray: length, strokeDashoffset: length, opacity: 0 },
              { strokeDashoffset: 0, opacity: 0.6, duration: 1.85, ease: 'power2.inOut' }, 1 + index * 0.15);
          });
        }

        // Bring the main compositions into the choreography, not just their headings.
        root.querySelectorAll('[data-stage]').forEach(stage => {
          gsap.fromTo(stage,
            { y: 76, autoAlpha: 0 },
            { y: 0, autoAlpha: 1, duration: 1.35, ease: 'power2.out',
              clearProps: 'transform,opacity,visibility',
              scrollTrigger: { trigger: stage, start: 'clamp(top 80%)', once: true } });
        });
        root.querySelectorAll('[data-photo-reveal]').forEach(frame => {
          gsap.fromTo(frame,
            { clipPath: 'inset(0% 100% 0% 0%)' },
            { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.5, ease: 'power2.inOut', clearProps: 'clipPath',
              scrollTrigger: { trigger: frame, start: 'clamp(top 80%)', once: true } });
        });

        // Create section entrances in document order. No pinning or scroll interception.
        root.querySelectorAll('[data-arrive], [data-sequence]').forEach(element => {
          if (hero?.contains(element)) return;
          if (element.hasAttribute('data-sequence')) {
            const items = Array.from(element.querySelectorAll('[data-sequence-item]'))
              .filter(item => item.closest('[data-sequence]') === element);
            if (!items.length) return;
            // Each card waits for its own viewport entry; tall mobile lists no
            // longer finish animating while their lower cards are still offscreen.
            items.forEach((item, index) => gsap.fromTo(item,
              { y: 64, autoAlpha: 0 },
              { y: 0, autoAlpha: 1, duration: 1.25, delay: (index % 3) * 0.1,
                ease: 'power2.out', clearProps: 'transform,opacity,visibility',
                scrollTrigger: { trigger: item, start: 'clamp(top 82%)', once: true } }));
            return;
          }
          // A card controlled by its sequence must not receive two entrance transforms.
          if (element.closest('[data-sequence-item]')) return;
          const direction = element.dataset.arrive;
          const x = direction === 'left' ? -46 : direction === 'right' ? 46 : 0;
          gsap.fromTo(element,
            { x, y: x ? 18 : 78, autoAlpha: 0 },
            {
              x: 0, y: 0, autoAlpha: 1, duration: 1.35, ease: 'power2.out',
              clearProps: 'transform,opacity,visibility',
              scrollTrigger: {
                trigger: element, start: 'clamp(top 78%)', once: true,
              },
            });
        });

        root.querySelectorAll('.journey-progress').forEach(path => {
          const horizontal = path.dataset.progressAxis === 'x';
          const property = horizontal ? 'scaleX' : 'scaleY';
          gsap.fromTo(path,
            { [property]: 0, transformOrigin: horizontal ? 'left center' : 'center top' },
            {
              [property]: 1, ease: 'none',
              scrollTrigger: {
                trigger: path.closest('[data-journey]') || path.parentElement,
                start: 'clamp(top 76%)', end: 'clamp(bottom 62%)', scrub: 0.7,
              },
            });
        });
      }, root);

      media.add('(min-width: 960px)', () => {
        root.querySelectorAll('[data-scene-parallax]').forEach(layer => {
          const supplied = Number.parseFloat(layer.dataset.sceneParallax);
          const distance = Number.isFinite(supplied) ? Math.min(44, Math.max(-44, supplied)) : 24;
          // Use a separate wrapper for reveal/scale if an image also participates in the intro.
          gsap.fromTo(layer, { y: -distance / 2 }, {
            y: distance / 2, ease: 'none',
            scrollTrigger: {
              trigger: layer.closest('[data-scene-frame]') || layer.parentElement,
              start: 'clamp(top bottom)', end: 'clamp(bottom top)', scrub: 0.9,
              invalidateOnRefresh: true,
            },
          });
        });
      }, root);
    }, root);

    const onToggle = event => {
      if (event.target instanceof HTMLDetailsElement) refresh();
    };
    const onVisibility = () => {
      if (!openingTimeline) return;
      if (document.hidden) openingTimeline.pause();
      else openingTimeline.resume();
    };
    // Changing coach or opening a teaching step may change the whole page height.
    // Observe layout dimensions, never animation transforms, and coalesce refreshes.
    let previousHeight = root.offsetHeight;
    let previousWidth = root.offsetWidth;
    if ('ResizeObserver' in window) {
      resizeObserver = new ResizeObserver(([entry]) => {
        if (!entry) return;
        const { width, height } = entry.contentRect;
        if (Math.abs(width - previousWidth) > 1 || Math.abs(height - previousHeight) > 1) {
          previousWidth = width; previousHeight = height; refresh();
        }
      });
      resizeObserver.observe(root);
    }
    root.addEventListener('load', refresh, true);
    root.addEventListener('toggle', onToggle, true);
    document.addEventListener('visibilitychange', onVisibility);
    document.fonts?.ready.then(() => { if (!stopped) refresh(); });

    return () => {
      stopped = true;
      window.cancelAnimationFrame(refreshFrame);
      resizeObserver?.disconnect();
      root.removeEventListener('load', refresh, true);
      root.removeEventListener('toggle', onToggle, true);
      document.removeEventListener('visibilitychange', onVisibility);
      media.revert();
      context.revert();
    };
  }, [rootRef, enabled, replayKey]);
}
