import React, { useEffect, useRef } from 'react';
import './SceneCursor.css';

/** The browser draws the pointer itself; only optional hover labels use JS. */
export default function SceneCursor({ enabled = true }) {
  const cursorRef = useRef(null);
  const labelRef = useRef(null);
  useEffect(() => {
    if (!enabled) return undefined;
    const cursor = cursorRef.current, label = labelRef.current;
    if (!cursor || !label) return undefined;
    const html = document.documentElement;
    const query = matchMedia('(hover: hover) and (pointer: fine) and (forced-colors: none)');
    let stopPointer;
    const setup = () => {
      let dragging = false, blocked = false, currentTarget = null;
      const hide = () => {
        cursor.dataset.visible = 'false'; cursor.dataset.label = 'false';
        label.textContent = ''; currentTarget = null;
        html.classList.remove('scene-cursor-enabled');
      };
      const checkDialog = () => {
        blocked = Boolean(document.querySelector('dialog[open], [role="dialog"][aria-modal="true"]:not([aria-hidden="true"]):not([hidden])'));
        if (blocked) hide();
      };
      const move = event => {
        const target = event.target;
        if (event.pointerType !== 'mouse' || dragging || event.buttons !== 0 || blocked || document.hidden ||
          target.isContentEditable || target.closest?.('input, textarea, select, [role="textbox"]')) { hide(); return; }
        // No interpolation, delayed scale, pointer capture, or preventDefault.
        html.classList.add('scene-cursor-enabled');
        cursor.dataset.visible = 'true';
        const x = Math.max(8, Math.min(event.clientX + 20, innerWidth - 165));
        const y = Math.max(8, Math.min(event.clientY + 22, innerHeight - 45));
        cursor.style.transform = `translate3d(${x}px, ${y}px, 0)`;
        const hoverTarget = target.closest?.('[data-pointer]');
        if (hoverTarget !== currentTarget) {
          currentTarget = hoverTarget;
          const disabled = target.closest?.(':disabled, [aria-disabled="true"]');
          label.textContent = disabled ? '' : (hoverTarget?.getAttribute('data-pointer') || '').replace(/\s+/g, ' ').trim().slice(0, 14);
          cursor.dataset.label = label.textContent ? 'true' : 'false';
        }
      };
      const press = () => { dragging = true; hide(); };
      const release = event => { dragging = false; move(event); };
      const cancel = () => { dragging = false; hide(); };
      const onKey = event => { if (['Tab', 'Escape', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.key)) hide(); };
      const onLeave = event => { if (!event.relatedTarget) hide(); };
      const onVisibility = () => { if (document.hidden) cancel(); };
      checkDialog();
      const dialogs = new MutationObserver(checkDialog);
      dialogs.observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['open', 'aria-modal', 'aria-hidden', 'hidden'] });
      window.addEventListener('pointermove', move, { passive: true });
      window.addEventListener('pointerdown', press, { passive: true });
      window.addEventListener('pointerup', release, { passive: true });
      window.addEventListener('pointercancel', cancel, { passive: true });
      window.addEventListener('lostpointercapture', cancel, { passive: true });
      window.addEventListener('blur', cancel);
      window.addEventListener('resize', hide, { passive: true });
      document.addEventListener('dragstart', press, { passive: true });
      document.addEventListener('dragend', cancel, { passive: true });
      document.addEventListener('drop', cancel, { passive: true });
      document.addEventListener('scroll', hide, { passive: true, capture: true });
      document.addEventListener('contextmenu', cancel, { passive: true });
      document.addEventListener('pointerout', onLeave, { passive: true });
      document.addEventListener('keydown', onKey);
      document.addEventListener('visibilitychange', onVisibility);
      return () => {
        cancel(); dialogs.disconnect();
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerdown', press);
        window.removeEventListener('pointerup', release);
        window.removeEventListener('pointercancel', cancel);
        window.removeEventListener('lostpointercapture', cancel);
        window.removeEventListener('blur', cancel);
        window.removeEventListener('resize', hide);
        document.removeEventListener('dragstart', press);
        document.removeEventListener('dragend', cancel);
        document.removeEventListener('drop', cancel);
        document.removeEventListener('scroll', hide, true);
        document.removeEventListener('contextmenu', cancel);
        document.removeEventListener('pointerout', onLeave);
        document.removeEventListener('keydown', onKey);
        document.removeEventListener('visibilitychange', onVisibility);
      };
    };
    const syncPointer = () => { stopPointer?.(); stopPointer = query.matches ? setup() : undefined; };
    syncPointer(); query.addEventListener('change', syncPointer);
    return () => { query.removeEventListener('change', syncPointer); stopPointer?.(); };
  }, [enabled]);
  return <div ref={cursorRef} className="scene-cursor" aria-hidden="true" data-visible="false" data-label="false"><span ref={labelRef} className="scene-cursor-label"/></div>;
}
